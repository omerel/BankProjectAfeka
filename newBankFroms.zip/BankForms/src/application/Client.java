package application;

public class Client {

	public Client() {
		// TODO Auto-generated constructor stub
	}

}
