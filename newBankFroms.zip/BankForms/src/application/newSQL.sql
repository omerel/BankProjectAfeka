

create table Test.bank
	(
		accountID int,
		id int
	);
create table Test.person
	( 
		id int primary key,
		 name varchar(20)
	);
create table Test.customer
	(
		id int,
		accountId int
	);
create table Test.banker
	(
		id int,
		type_ varchar(20),
		user_ varchar(20),
		password varchar(20)
	);
create table Test.account
	(
		accountId int primary key,
		 balance double
	);
create table Test.loan
	(
		loanId int primary key,
		 accountId int,
		 amount double,
		 monthPayment double,
		 interest varchar(40)
	);
create table Test.savings
	(
		savingId int primary key,
		accountId int,
		balance double,
		ratio double
	);
create table Test.operations
	(
		operationId int primary key,
		accountId int,
		type_ varchar(20),
		day date,
		amount double,
		description varchar(40)
	);
