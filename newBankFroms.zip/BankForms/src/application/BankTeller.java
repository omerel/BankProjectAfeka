package application;


public class BankTeller extends Employee{

	public BankTeller(int id,String name,int EmployeeNum) {
		super(id,name,EmployeeNum);
	}
	public void ManageClients(){
		
	}

	
	
}
