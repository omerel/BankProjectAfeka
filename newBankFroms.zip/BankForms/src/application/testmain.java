package application;


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSetMetaData;

import org.apache.derby.jdbc.EmbeddedDriver;
public class testmain
{
	
    private static String dbURL = "jdbc:derby:C:/Users/adeem/MyDB";
    private static String tableName = "person";
    // jdbc Connection
    private static Connection conn = null;
    private static Statement stmt = null;

    public static void main(String[] args)
    {
        createConnection();
        System.out.println("BLABALBALBALBLA");
        insertRestaurants( 4, "Tal");
    }
    
    private static void insertRestaurants(int id, String restName)
    {
        try
        {        	
            stmt = conn.createStatement();
           // stmt.execute("insert into " + tableName + " values (" +
            //        id + ",'" + restName +"')");
           // stmt.close();
        }
        catch (SQLException sqlExcept)
        {
        	System.out.println("failed");
            sqlExcept.printStackTrace();
        }
    }
    
    private static void createConnection()
    {
    	
        try
        {
        	Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            conn = DriverManager.getConnection(dbURL); 
        }
        catch (Exception except)
        {
        	 System.out.println("BAD");
            except.printStackTrace();
        }
    }
}