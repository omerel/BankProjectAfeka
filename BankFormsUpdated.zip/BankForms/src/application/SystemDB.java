package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
//download fx library : http://www.java2s.com/Code/Jar/j/Downloadjavafxuicommonjar.htm


import javafx.scene.image.Image;
//here is the main system that we directly connect to the database!!.
public class SystemDB {
private List<Employee> allEmloyees;
private List<Client> allClients;
private List<Account> allAccounts;
private boolean ManagerFlag;
private int bankID;
private static String dbURL = "jdbc:derby:C:/Users/Viroket/BANK/BankDB";
private static Connection conn = null;
private static java.sql.Statement stmt = null;

ArrayList<Statement> statements = new ArrayList<Statement>(); // list of Statements, PreparedStatements
PreparedStatement psInsert;
PreparedStatement psUpdate;
PreparedStatement psDelete;
Statement s;
ResultSet rs = null;


	public SystemDB(int bankID) {
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
			conn = DriverManager.getConnection(dbURL);
			conn.setAutoCommit(false);
			            
			s = conn.createStatement();
            statements.add(s);
		}catch(Exception except){
			except.printStackTrace();
			System.out.println("failed");
			System.exit(0);
		}
		System.out.println("Connected to database");
		this.bankID = bankID;
		this.allAccounts = new ArrayList<>();
		this.allClients = new ArrayList<>();
		this.allEmloyees  = new ArrayList<>();
		this.ManagerFlag = false;
	}
	
	//////////////////////////////////////insert test/////////////////////////////////
	public void printhello() {
		System.out.println("hello, from system, id  = "+this.bankID);
		try{

			
            psInsert = conn.prepareStatement(
                        "insert into BANK values (?, ?, ? , ?)");
            statements.add(psInsert);
            psInsert.setString(1,"Bank 1 ");
            psInsert.setString(2,"Bank 1@gmail ");
            
            psInsert.setInt(3, 10909090);
            psInsert.setInt(4, 2);
            psInsert.executeUpdate();
            
            System.out.println("Inserted 1956 222");
    	
            rs = s.executeQuery( "SELECT Name, phoneNumber, id FROM BANK ORDER BY id");
            
            while(rs.next()){
            	String n = rs.getString(1);
            	System.out.println(n);
            }
            
            conn.commit();
            
            psInsert = conn.prepareStatement(
                    "insert into BANK values (?, ?, ? , ?)");
        statements.add(psInsert);
        psInsert.setString(1,"Bank 2");
        psInsert.setString(2,"Bank 1@gmail ");
        
        psInsert.setInt(3, 10909090);
        psInsert.setInt(4, 2);
        psInsert.executeUpdate();
         System.out.println("Committed the transaction 2");
         conn.commit();
		}catch(Exception e){
			System.out.println("failer to send data");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		//////////////////////////////////////insert/////////////////////////////////
		
		////////////////////////////////////////deleting test ////////////////////////////
		try{
			psDelete = conn.prepareStatement(
	                "delete from BANK where =(?, ?, ? , ?)");
			psInsert.setString(1,"Bank 1 ");
            psInsert.setString(2,"Bank 1@gmail ");
            
            psInsert.setInt(3, 10909090);
            psInsert.setInt(4, 2);

            conn.commit();
		}catch(Exception e){
			System.out.println("failer to send data");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		////////////////////////////////////////deleting////////////////////////////
		
	}
	private void print(String s){
		System.out.println(s);
	}
	private void ManageClientsForm(Client c,int whatToDo){//1-add , 2- remove , 3- update.
		print("Manage Clinets Form");
	}
	private void ManageEmployeesForm(Employee e, int whatToDo){//1-add , 2- remove , 3- update.
		print("Manage Employees Form");
		//display form
	}
	private void ManageManagersForm(){
		print("Manage Managers Form");
	}
	private void ManageAccountsForm(){
		print("Manage Accounts Form");
	}
	public boolean AddClient(int ID,String name,Image photo){
		Client c = null;
		//Add the client to the database and check if there are no errors (id matches others ... etc).
		this.ManageClientsForm(c,1);
		return true;
	}
	public boolean RemoveClient(int ID,String name,Image photo){
		Client c = null;
		//Add the client to the database and check if there are no errors (id matches others ... etc).
		this.ManageClientsForm(c,2);
		return true;
	}
	public boolean AddEmployee(String type,int ID,String name,String password,int phoneNumber){
		//Add the client to the database and check if there are no errors (id matches others ... etc).
		System.out.println("adding the new employee");	
		try{	
			if(type.equals("Banker")){
			
            psInsert = conn.prepareStatement("insert into  BANKER values (?, ?, ? , ?)");
            statements.add(psInsert);

            psInsert.setInt(1, ID);
            psInsert.setString(2, name);//implement email if needed
            psInsert.setString(3,password);
            psInsert.setInt(4, phoneNumber);
			}
			else{
	            psInsert = conn.prepareStatement(
                        "insert into EMPLOYEE values (?, ?, ?)");	
	            statements.add(psInsert);

	            psInsert.setString(1, name);
	            psInsert.setInt(2, phoneNumber);
	            psInsert.setInt(3, ID);
			}
            psInsert.executeUpdate();
            
            System.out.println("ADDED EMPLOYEE TO THE SYSTEM");
    	
            conn.commit();
            System.out.println("added employee ");
            
		}catch(Exception e1){
			System.out.println("failer to ADD EMPLOYEE data");
			try {
				conn.rollback();
			} catch (SQLException e11) {
				// TODO Auto-generated catch block
				e11.printStackTrace();
			}
		}	
		return true;
	}
	public boolean RemoveEmployee(String type,int ID,String name,Image photo){
		Employee e = null;
		//Add the client to the database and check if there are no errors (id matches others ... etc).
		this.ManageEmployeesForm(e, 2);
		return true;
	}
	public boolean isManager(){
		return this.ManagerFlag;
	}
	public void setManager(){
		this.ManagerFlag = true;
	}	
	public boolean CheckNomalLogin(int ID, String passWord){
		//check if the info is correct.
		return true;
	}	
	public boolean CheckManagerLogin(int ID, String passWord){
		//check if the info is correct.
		//if the manager is loggen in then the flag is set to true;
		// only when the manager flag is true we can access the manage employees page.
		return true;
	}	
	public boolean AddAccount(int accoutnid, int Password, double balance){		
		//add the account to the system.
		return true;
	}
	public boolean RemoveAccount(int accoutnid, int Password){
		//remove the account from the system.
		return true;
	}
	public boolean withdrawMoney(int accountID, double ammount){
		//Withdraw the amount from the account, if possible.
		return true;
	}
	public boolean TransferMoney(int accountID){
		//Transfer money between account, check if possible.
		return true;
	}
	public double CheckBalance(int accountID){
		//return the balance of the account
		return 0;
	}
	public boolean depositMoney(int accountID){
		//deposit money into the account, no checking needed.
		return true;
	}
}
