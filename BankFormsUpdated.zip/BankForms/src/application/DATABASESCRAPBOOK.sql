connect 'jdbc:derby:BankDB;create=true';


create table BANK
	(
		Name varchar(20),
		EmailAdress varchar(20),
		phoneNumber int,
		id int
	);
create table EMPLOYEE(
Name varchar(20),
phoneNumber int,
id int
);
create table PERSON
	( 
		id int primary key,
		name varchar(20)
	);
drop table CLIENT;
drop table ACCOUNT;
drop table BANKER;
drop table BANKER
create table BANKER
	(
		id int,
		Name varchar(20),
		password varchar(20),
		PhoneNumber int
	);
create table CLIENT
	(
		Name varchar(20),
		id int primary key,
		Accountid int
	);
select * from BANKER
create table ACCOUNT
	(
		accountId int primary key,
		balance double,
		Password int
	);
create table LOAN
	(
		loanId int primary key,
		 accountId int,
		 amount double,
		 monthPayment double,
		 interest varchar(40)
	);
create table SAVINGS
	(
		savingId int primary key,
		accountId int,
		balance double,
		ratio double
	);
create table OPERATIONS
	(
		operationId int primary key,
		accountId int,
		Type varchar(20),
		day date,
		amount double,
		description varchar(40)
	);
