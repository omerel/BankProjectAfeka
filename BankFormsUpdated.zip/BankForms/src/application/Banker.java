package application;


public class Banker extends Employee{

	public Banker(int id,String name,int EmployeeNum) {
		super(id,name,EmployeeNum);
	}
	public void ManageClients(){
		
	}

	
	
}
